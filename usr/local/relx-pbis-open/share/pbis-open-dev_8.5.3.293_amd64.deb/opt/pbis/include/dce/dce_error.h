/* pull in the header as determined for this platform at configure time */
#include <dce/linux-gnu/dce_error.h>
